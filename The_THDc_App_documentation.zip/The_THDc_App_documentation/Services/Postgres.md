# [Postgres](https://github.com/THD-C/Postgres)

![image](https://raw.githubusercontent.com/THD-C/DB_Manager/main/ERD.png)

PostgreSQL container, fully managed by [DB Manager](https://github.com/THD-C/DB_Manager), which is responsible for everything related to SQL data storage.
Starting with creating the Database in PostgreSQL and managing CRUD operations.

